const mysql = require("mysql");
const pool = mysql.createPool({
  host: "mysql-private-db.cahh4sebpiaj.us-east-2.rds.amazonaws.com",
  user: "root",
  password: "rootroot",
  database: "masyanya-vpc-db",
});

exports.handler = async (event) => {
  const {
    sensor_id,
    time_stamp,
    sensor_type,
    sensor_name,
    api_key,
    sensor_data,
  } = event;

  let response = {};
  const query = `SELECT * FROM sensors_data WHERE sensor_id=${sensor_id} LIMIT 1`;
  pool.query(query, (err, results, fields) => {
    if (err) {
      const response1 = { data: null, message: err.message };
      response = {
        statusCode: 404,
        body: JSON.stringify(response1),
      };
      return response;
    }

    const { sensor_id, sensor_type, sensor_name, api_key, sensor_data } = {
      ...results[0],
      ...event,
    };

    const query = `UPDATE sensors_data SET sensor_type='${sensor_type}', sensor_name='${sensor_name}', api_key='${api_key}', sensor_data='${sensor_data}' WHERE sensor_id='${sensor_id}'`;
    pool.query(query, (err, results, fields) => {
      if (err) {
        const response1 = { data: null, message: err.message };
        response = {
          statusCode: 404,
          body: JSON.stringify(response1),
        };
        return response;
      }

      const bus_data = {
        sensor_id,
        sensor_type,
        sensor_name,
        api_key,
        sensor_data,
      };
      const response1 = {
        data: bus_data,
        message: `Bus data ${sensor_id} is successfully updated.`,
      };
      response = {
        statusCode: 201,
        body: JSON.stringify(response1),
      };
      return response;
    });
  });
};
